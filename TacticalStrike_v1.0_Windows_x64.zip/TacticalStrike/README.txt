==========================================================
  TACTICAL STRIKE v1.0  -  Windows x64
  An ORIGINAL offline tactical FPS inspired by classic 1.6 gameplay
==========================================================

All content is original (weapons, map "FACILITY", synthesized sounds,
low-poly visuals). No copyrighted Counter-Strike assets are used.

----------------------------------------------------------
1. HOW TO RUN
----------------------------------------------------------
- Extract the whole folder anywhere on your disk.
- Double-click  TacticalStrike.exe  -> the game starts directly.
- No installation, no browser, no internet needed (internet is only
  used for the OPTIONAL Telegram notifications).

----------------------------------------------------------
2. SYSTEM REQUIREMENTS
----------------------------------------------------------
- Windows 10 / 11 (64-bit)
- OpenGL 3.3 capable GPU (any integrated GPU from ~2012 works)
- ~50 MB disk space
- Keyboard + mouse

----------------------------------------------------------
3. CONTROLS
----------------------------------------------------------
  W A S D ....... Move
  MOUSE ......... Aim
  LEFT MOUSE .... Fire
  RIGHT MOUSE ... Aim down sights / sniper scope
  R ............. Reload
  E (hold) ...... Plant bomb / defuse bomb
  G ............. Throw currently selected grenade
  1 - 5 ......... Weapon slots (1 primary, 2 pistol, 3 knife,
                  4 grenades, 5 C4)
  MOUSE WHEEL ... Cycle weapons
  CTRL .......... Crouch
  SHIFT ......... Walk quietly (slower, silent)
  SPACE ......... Jump
  TAB (hold) .... Scoreboard
  B ............. Buy menu
  ESC ........... Pause / back

----------------------------------------------------------
4. GRAPHICS SETTINGS
----------------------------------------------------------
In SETTINGS you can change: Resolution, Fullscreen, VSync,
Graphics Quality (LOW / MEDIUM / HIGH), Shadows, Mouse sensitivity,
FOV, Master/Music/Effects volume and Crosshair style.
All settings are saved to settings.cfg next to the exe.

Tips for low-end PCs:
- Set Graphics Quality = LOW and Shadows = OFF.
- The game targets 60 FPS on almost any hardware.

----------------------------------------------------------
5. HOW TO CONFIGURE TELEGRAM (OPTIONAL)
----------------------------------------------------------
The game can send you notifications: Game Started, Round Won/Lost,
Bomb Planted, Bomb Defused, New High Score, Match Finished.

Option A - in-game:
  Main menu -> TELEGRAM -> fill Bot Token + Chat ID ->
  Enable notifications: ON -> SAVE -> TEST CONNECTION.

Option B - file:
  Open telegram_config.json next to the exe:
  {
    "bot_token": "123456:ABC...",
    "chat_id":   "123456789",
    "enabled":   true
  }

----------------------------------------------------------
6. HOW TO CREATE A TELEGRAM BOT (BotFather)
----------------------------------------------------------
1. Open Telegram and search for  @BotFather  (verified bot).
2. Send  /newbot  and follow the steps (pick a name + username).
3. BotFather replies with a token like:
   123456789:AAE-xxxxxxxxxxxxxxxxxxxxxxxxxxx
   -> This is YOUR_BOT_TOKEN.

----------------------------------------------------------
7. HOW TO OBTAIN YOUR CHAT ID
----------------------------------------------------------
1. Open your bot in Telegram and press START (send any message).
2. Search for  @userinfobot  and send it any message.
3. It replies with your numeric "Id"  -> This is YOUR_CHAT_ID.

----------------------------------------------------------
8. HOW TO TEST TELEGRAM
----------------------------------------------------------
- Menu -> TELEGRAM -> TEST CONNECTION.
- If everything is right you receive "Telegram connection successful!"
  and the screen shows "Last message: DELIVERED".
- If it fails, check: exact token, correct chat id, and that you
  pressed START in your bot chat at least once.

----------------------------------------------------------
9. HOW TO DISABLE TELEGRAM
----------------------------------------------------------
- In game: TELEGRAM -> Enable notifications: OFF -> SAVE.
- Or in telegram_config.json set  "enabled": false.
- Or simply delete telegram_config.json.

----------------------------------------------------------
10. SECURITY NOTES (IMPORTANT)
----------------------------------------------------------
- Your bot token is a SECRET. Anyone who has it can control your bot.
- It is stored only in telegram_config.json on YOUR disk.
- Do NOT publish it, do NOT upload it to GitHub, do NOT share screenshots
  containing it.
- If it leaks: open @BotFather -> /mybots -> your bot -> API Token -> Revoke.

----------------------------------------------------------
11. GAME MODES
----------------------------------------------------------
- BOMB DEFUSAL: round-based, first to 8 rounds. Terrorists plant the
  C4 at Site A or B (hold E). Bomb timer 40 s. CTs defuse (hold E,
  10 s). Economy: start $800, kill up to $1500 (knife), win $3250,
  loss bonus $1400 - $3400, plant/defuse $300.
- TEAM DEATHMATCH: respawns enabled, first team to 50 kills or best
  score after 10:00 wins.
- PRACTICE: free roam, infinite money, bots patrol but never fire.

WEAPONS (all original):
  Combat Knife | P9 Compact | Vulture .50 | Viper SMG | Mauler 12G
  Vanguard AR (CT) | Raptor AK (T) | Longbow SR (sniper)
EQUIPMENT: HE Grenade, Flashbang, Smoke Grenade, Kevlar, Kevlar+Helmet.

----------------------------------------------------------
12. HOW TO BUILD FROM SOURCE
----------------------------------------------------------
Source files (main.cpp, world.cpp, player.cpp, bots.cpp, rounds.cpp,
hud.cpp, menus.cpp, settings.cpp, telegram.cpp, audio.cpp, sysutil_win.cpp
+ headers) require raylib 5.5.

With a MinGW-w64 toolchain:
  g++ -std=c++17 -O2 *.cpp -o TacticalStrike.exe ^
      -Iraylib/include -Lraylib/lib -lraylib -lopengl32 -lgdi32 -lwinmm -lwinhttp ^
      -static -Wl,--subsystem,windows

The game was built with raylib 5.5 (www.raylib.com) - zlib licensed.

----------------------------------------------------------
Release contents
----------------------------------------------------------
TacticalStrike.exe........ the game (standalone, x64)
assets\sounds\............ all original procedural sounds
telegram_config.json...... your Telegram credentials (keep private!)
telegram_config.json.example safe template without credentials
README.txt................ this file
settings.cfg / stats.cfg.. created automatically after first run

Have fun!
